--
-- Database: `gps`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `contactperson` (IN `first_name` VARCHAR(20), IN `last_name` VARCHAR(20), IN `position` VARCHAR(20), IN `address_one` VARCHAR(50), IN `address_two` VARCHAR(50), IN `city` VARCHAR(20), IN `province` VARCHAR(20), IN `contact_number` VARCHAR(11), IN `organization` VARCHAR(20), IN `email_add` VARCHAR(50))  BEGIN

insert into contact_person (first_name ,
last_name ,
position ,
address_one ,
address_two ,
city ,
province ,
contact_number ,
organization ,
email_add )
values (first_name ,
last_name ,
position ,
address_one ,
address_two ,
city ,
province ,
contact_number ,
organization ,
email_add );



 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getantennainfo` (IN `id` VARCHAR(15))  BEGIN

select antenna_serialnumber, antenna_serialnumber,  antenna_partnumber, antenna_type 
from antenna_information 
where antenna_serialnumber = id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getreceiverinfo` (IN `id` VARCHAR(15))  BEGIN

select serial_number,receiver_type, part_number
from receiver_information 
where serial_number = id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getsiteinformation` (IN `id` VARCHAR(15))  BEGIN
select 
 A.site_name,A.latitude,A.longitude,A.address_one, A.address_two,A.city,A.province,
 B.serial_number,B.receiver_type,B.part_number,D.antenna_serialnumber,D.antenna_charcode,
 D.antenna_name,D.antenna_type, E.ps_serial_number,E.comment,F.first_name, F.last_name, F.position, F.contact_number, F.organization,F.email_add,
 F.address_one, F.address_two, F.city, F.province, G.gallery_name,H.image_name,H.image_path,I.image_class_type
 
from site_information as A , receiver_information as B, antenna_information as D,
     power_source as E, contact_person as F, gallery as G, site_images as H, image_class as I
     
where A.site_name = id or A.receiver_sn = B.serial_number or A.receiver_sn = B.serial_number or A.antenna_sn = D.antenna_serialnumber
or A.powersource_sn = E.ps_serial_number or A.contact_id = F.contact_id or A.gallery_name = G.gallery_name or 
G.image_name = H.image_name or H.image_clas_id = I.Image_clas_id;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `gpsstaff` (IN `first_name` VARCHAR(20), IN `last_name` VARCHAR(20), IN `position_name` VARCHAR(20), IN `contact_num` VARCHAR(20), IN `division_name` VARCHAR(10), IN `email_address` VARCHAR(50), IN `office_location` VARCHAR(20), IN `nickname` VARCHAR(10), IN `birthday` DATE)  BEGIN

insert into gps_staff_info(
 first_name, 
 last_name ,
 position_name,
 contact_num ,
 division_name, 
 email_address, 
 office_location,
 nickname,
 birthday
)
values(
 first_name, 
 last_name ,
 position_name,
 contact_num ,
 division_name, 
 email_address, 
 office_location,
 nickname,
 birthday
);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `logsheet` (IN `logsheet_date` DATE, IN `julian_day` INT(5), IN `marker` VARCHAR(5), IN `height` DECIMAL(10,5), IN `north` DECIMAL(10,3), IN `east` DECIMAL(10,3), IN `south` DECIMAL(10,3), IN `west` DECIMAL(10,3), IN `time_start` TIME, IN `time_end` TIME, IN `azimuth` INT(10), IN `failure_time` TIME, IN `receiver_status` LONGTEXT, IN `antenna_status` LONGTEXT, IN `rod_num` INT(10), IN `rod_correction` INT(10), IN `avg_slant_height` DECIMAL(10,5), IN `netmask` VARCHAR(20), IN `gateway` VARCHAR(20), IN `dns` VARCHAR(20), IN `local_tcp_port` INT(5), IN `lattitude` DECIMAL(10,5), IN `longitude` DECIMAL(10,5), IN `observed_situation` LONGTEXT, IN `lodging_road_information` LONGTEXT, IN `others` LONGTEXT, IN `ip_add` VARCHAR(20))  BEGIN

 insert into logsheet (
logsheet_date,julian_day,marker,power_source,height,
north,east,south,west,time_start,
time_end,azimuth, 
failure_time,receiver_status,
antenna_status ,rod_num,rod_correction,
avg_slant_height,netmask,gateway,
dns,local_tcp_port,lattitude,longitude,observed_situation,lodging_road_information,others,ip_add)
 values (
logsheet_date,julian_day,marker,power_source,height,
north,east,south,west,time_start,
time_end,azimuth, ip_add,
failure_time,receiver_status,
antenna_status ,rod_num,rod_correction,
avg_slant_height,netmask,gateway,
dns,local_tcp_port,lattitude,longitude,observed_situation,lodging_road_information,others);
 
 
 
 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `siteiformation` (IN `site_name` VARCHAR(15), IN `last_update` DATE, IN `latitude` DOUBLE(10,5), IN `longitude` DOUBLE(10,5), IN `receiver_sn` VARCHAR(15), IN `antenna_sn` VARCHAR(15), IN `powersource_sn` VARCHAR(15), IN `contact_id` TINYINT(4), IN `address_one` VARCHAR(50), IN `address_two` VARCHAR(50), IN `city` VARCHAR(20), IN `province` VARCHAR(20), IN `gallery_name` VARCHAR(10), IN `image_name` VARCHAR(10))  BEGIN

insert into site_information(
 site_name ,
 last_update, 
 latitude ,
 longitude ,
 receiver_sn, 
 antenna_sn,
 powersource_sn ,
 contact_id ,
 address_one ,
 address_two ,
 city ,
 province ,
 gallery_name 
)
values(
site_name ,
 last_update, 
 latitude ,
 longitude ,
 receiver_sn, 
 antenna_sn,
 powersource_sn ,
 contact_id ,
 address_one ,
 address_two ,
 city ,
 province ,
 gallery_name 
);

insert into gallery(gallery_name, image_name)
values (gallery_name, image_name);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_insert_employee` (OUT `employee_id` INT, IN `employee_name` VARCHAR(25), IN `employee_contact` VARCHAR(25))  BEGIN
  insert into test_table(name, contact)
  values(employee_name, employee_contact);
  set employee_id = LAST_INSERT_ID();
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `antenna_information`
--

CREATE TABLE `antenna_information` (
  `antenna_id` tinyint(4) NOT NULL,
  `antenna_serialnumber` varchar(50) NOT NULL,
  `antenna_partnumber` varchar(50) NOT NULL,
  `antenna_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antenna_information`
--

INSERT INTO `antenna_information` (`antenna_id`, `antenna_serialnumber`, `antenna_partnumber`, `antenna_type`) VALUES
(1, '123456789', 'adad', 'daa'),
(2, '1440929209', '57971-00 DC 4937', 'Zephyr Geodetic Model 2'),
(3, '1441021247', '57971-00 DC 5024', 'Zephyr Geodetic Model 2'),
(4, '1441021343', '57971-00 DC 5024', 'Zephyr Geodetic Model 2'),
(5, '1441021516', '57971-00 DC 5024', 'Zephyr Geodetic Model 2'),
(6, '1441027115', '57971-00 DC 5031', 'Zephyr Geodetic Model 2'),
(7, '1441027148', '57971-00 DC 5031', 'Zephyr Geodetic Model 2'),
(8, '1441027374', '57971-00 DC 5031', 'Zephyr Geodetic Model 2'),
(9, '1441027586', '57971-00 DC 5031', 'Zephyr Geodetic Model 2'),
(10, '1441027979', '57971-00 DC 5031', 'Zephyr Geodetic Model 2'),
(11, '12382983', '41249-00 DC 4235', 'Zephyr Geodetic'),
(12, '12382994', '41249-00 DC 4235', 'Zephyr Geodetic'),
(13, '12383088', '41249-00 DC 4235', 'Zephyr Geodetic'),
(14, '12393268', '41249-00 DC 4235', 'Zephyr Geodetic'),
(15, '12393278', '41249-00 DC 4235', 'Zephyr Geodetic'),
(16, '12393346', '41249-00 DC 4235', 'Zephyr Geodetic'),
(17, '60220467', '41249-00 DC 4732', 'Zephyr Geodetic'),
(18, '60250556', '41249-00 DC 4838', 'Zephyr Geodetic'),
(19, '60251466', '41249-00 DC 4838', 'Zephyr Geodetic'),
(20, '60267892', '41249-00 DC 4918', 'Zephyr Geodetic'),
(21, '12545333', '41249-00 DC 4345', 'Zephyr Geodetic'),
(22, '12518000', '41249-00 DC 4345', 'Zephyr Geodetic');

-- --------------------------------------------------------

--
-- Table structure for table `associated_agency`
--

CREATE TABLE `associated_agency` (
  `agency_id` tinyint(4) NOT NULL,
  `associated_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `associated_agency`
--

INSERT INTO `associated_agency` (`agency_id`, `associated_name`) VALUES
(1, 'DENR-LMB'),
(2, 'EOS'),
(3, 'IESAS'),
(4, 'LGU'),
(5, 'NAMRIA'),
(6, 'NCKU'),
(7, 'PHIVOLCS');

-- --------------------------------------------------------

--
-- Table structure for table `contact_person`
--

CREATE TABLE `contact_person` (
  `contact_id` tinyint(4) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `position` varchar(20) NOT NULL,
  `contact_number` varchar(11) NOT NULL,
  `organization` varchar(20) NOT NULL,
  `email_add` varchar(50) NOT NULL,
  `address_one` varchar(50) NOT NULL,
  `address_two` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_person`
--

INSERT INTO `contact_person` (`contact_id`, `first_name`, `last_name`, `position`, `contact_number`, `organization`, `email_add`, `address_one`, `address_two`, `city`, `province`) VALUES
(1, 'michael john', 'peralta', 'caretaker', '123456789', 'gps', 'test', 'testadd', 'testaa', 'city', 'pronvice'),
(2, 'oriell', 'orielle', 'caretaker', '123456789', 'gps', 'test', 'test', 'test', 'test', 'test'),
(3, 'rueshella', 'rueshella', 'secretary', '123456789', 'gps', 'testemailafdd', 'testemail', 'testemail', 'city', 'province');

-- --------------------------------------------------------

--
-- Table structure for table `data_table`
--

CREATE TABLE `data_table` (
  `site_id` tinyint(4) NOT NULL,
  `date` double NOT NULL,
  `east` decimal(10,5) NOT NULL,
  `north` decimal(10,5) NOT NULL,
  `up` decimal(10,5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fieldwork_table`
--

CREATE TABLE `fieldwork_table` (
  `fieldwork_id` tinyint(4) NOT NULL,
  `first_date` date NOT NULL,
  `last_date` date NOT NULL,
  `logistical_note_id` tinyint(4) NOT NULL,
  `others` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `gallery_id` tinyint(10) NOT NULL,
  `gallery_name` varchar(10) NOT NULL,
  `image_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gallery_id`, `gallery_name`, `image_name`) VALUES
(0, 'gallery na', 'sitenameye');

-- --------------------------------------------------------

--
-- Table structure for table `gps_staff_info`
--

CREATE TABLE `gps_staff_info` (
  `staf_id` tinyint(4) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `nickname` varchar(10) NOT NULL,
  `position_name` varchar(20) NOT NULL,
  `contact_num` varchar(20) NOT NULL,
  `division_name` varchar(10) NOT NULL,
  `email_address` varchar(50) NOT NULL,
  `office_location` varchar(20) NOT NULL,
  `birthday` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gps_staff_info`
--

INSERT INTO `gps_staff_info` (`staf_id`, `first_name`, `last_name`, `nickname`, `position_name`, `contact_num`, `division_name`, `email_address`, `office_location`, `birthday`) VALUES
(1, 'test', 'test', '', 'undefined', 'test', 'test', 'test', 'test', '0000-00-00'),
(2, 'Genesis Jr.', 'Sapla', 'Geno', 'SRS I', '123456789', 'GGRDD', 'testing', 'Main Office', '1987-11-19'),
(3, 'Teresito', 'Bacolcol', 'Toto', 'Associate Scientist', '123456789', 'GGRDD', 'testing', 'Main Office', '2017-03-31'),
(4, 'Alfie', 'Pelicano', 'Alfie', 'SRS II', '123456789', 'GGRDD', 'testing', 'Main Office', '1982-11-03');

-- --------------------------------------------------------

--
-- Table structure for table `image_class`
--

CREATE TABLE `image_class` (
  `image_clas_id` tinyint(4) NOT NULL,
  `image_class_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logistical_notes`
--

CREATE TABLE `logistical_notes` (
  `logistical_note_id` tinyint(4) NOT NULL,
  `accessibility` longtext NOT NULL,
  `site stability` longtext NOT NULL,
  `contruction_dev_plans` longtext NOT NULL,
  `accommodation` longtext NOT NULL,
  `associated_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logsheet`
--

CREATE TABLE `logsheet` (
  `logsheet_id` tinyint(4) NOT NULL,
  `fieldwork_id` tinyint(4) NOT NULL,
  `site_name` varchar(10) NOT NULL,
  `survey_type` varchar(10) NOT NULL,
  `logsheet_date` date NOT NULL,
  `julian_day` int(5) NOT NULL,
  `marker` varchar(5) NOT NULL,
  `receiver_serailnumber` varchar(15) NOT NULL,
  `antenna_serialnumber` varchar(15) NOT NULL,
  `height` decimal(10,5) NOT NULL,
  `north` decimal(10,3) NOT NULL,
  `east` decimal(10,3) NOT NULL,
  `south` decimal(10,3) NOT NULL,
  `west` decimal(10,3) NOT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `azimuth` int(10) NOT NULL,
  `scan_log_id` tinyint(4) NOT NULL,
  `power_source_serialnumber` varchar(15) NOT NULL,
  `failure_time` time NOT NULL,
  `receiver_status` longtext NOT NULL,
  `antenna_status` longtext NOT NULL,
  `rod_num` int(10) NOT NULL,
  `rod_correction` int(10) NOT NULL,
  `avg_slant_height` decimal(10,5) NOT NULL,
  `ip_add` varchar(20) NOT NULL,
  `netmask` varchar(20) NOT NULL,
  `gateway` varchar(20) NOT NULL,
  `dns` varchar(20) NOT NULL,
  `local_tcp_port` int(5) NOT NULL,
  `lattitude` decimal(10,5) NOT NULL,
  `longitude` decimal(10,5) NOT NULL,
  `site_sketch_id` tinyint(4) NOT NULL,
  `observed_situation` longtext NOT NULL,
  `lodging_road_information` longtext NOT NULL,
  `contact_id` tinyint(4) NOT NULL,
  `others` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `observer`
--

CREATE TABLE `observer` (
  `observer_id` tinyint(4) NOT NULL,
  `staff_id` tinyint(4) NOT NULL,
  `fieldwork_id` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `office_division`
--

CREATE TABLE `office_division` (
  `division_id` tinyint(4) NOT NULL,
  `division` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `office_division`
--

INSERT INTO `office_division` (`division_id`, `division`) VALUES
(4, 'ADMIN/SCIENCE AIDE'),
(5, 'GDAP'),
(1, 'GGRDD'),
(2, 'SOEPD'),
(3, 'VMEPD');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `position_id` tinyint(4) NOT NULL,
  `position_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`position_id`, `position_name`) VALUES
(3, 'Admin Aide I'),
(4, 'Admin Aide II'),
(5, 'Admin Aide III'),
(6, 'Admin Aide IV'),
(7, 'Admin Aide V'),
(13, 'Associate Scientist'),
(1, 'Job Order'),
(2, 'Science Aide'),
(14, 'Senior SRS'),
(12, 'SR Analyst'),
(11, 'SR Assistant'),
(8, 'SRS I'),
(9, 'SRS II'),
(10, 'SRS III');

-- --------------------------------------------------------

--
-- Table structure for table `power_source`
--

CREATE TABLE `power_source` (
  `ps_id` tinyint(4) NOT NULL,
  `ps_serial_number` varchar(15) NOT NULL,
  `comment` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `receiver_information`
--

CREATE TABLE `receiver_information` (
  `receiver_id` tinyint(4) NOT NULL,
  `serial_number` varchar(20) NOT NULL,
  `receiver_type` varchar(50) NOT NULL,
  `part_number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receiver_information`
--

INSERT INTO `receiver_information` (`receiver_id`, `serial_number`, `receiver_type`, `part_number`) VALUES
(1, '123456789', 'adad', 'dadada'),
(2, '3551A13863', 'Trimble 4000SSi', '24840-41'),
(3, '3551A13917', 'Trimble 4000SSi', '24840-41'),
(4, '3905A25361', 'Trimble 4000SSi', '24840-41'),
(5, '3906A25428', 'Trimble 4000SSi', '24840-41'),
(6, '3941A26962', 'Trimble 4000SSi', '24840-41'),
(7, '4017A28158', 'Trimble 4000SSi', '24840-41'),
(8, '4023A28515', 'Trimble 4000SSi', '24840-41'),
(9, '4906165518', 'Trimble 5700 II', '65873-00'),
(10, '4906165602', 'Trimble 5700 II', '65873-00'),
(11, '4911166850', 'Trimble 5700 II', '65873-00'),
(12, '4911166851', 'Trimble 5700 II', '65873-00'),
(13, '4912167239', 'Trimble 5700 II', '65873-00'),
(14, '4912167244', 'Trimble 5700 II', '65873-00'),
(15, '4912167254', 'Trimble 5700 II', '65873-00'),
(16, '4912167255', 'Trimble 5700 II', '65873-00'),
(17, '4935400803', 'Trimble 5700 II', '65873-00'),
(18, '0220294779', 'Trimble 5700', '40406-00'),
(19, '0220358872', 'Trimble 5700', '40406-00'),
(20, '0220281552', 'Trimble 5700', '40406-32'),
(21, '0220294778', 'Trimble 5700', '40406-32'),
(23, '0220294780', 'Trimble 5700', '40406-32'),
(24, '0220294782', 'Trimble 5700', '40406-32'),
(25, '0220294783', 'Trimble 5700', '40406-32'),
(26, '0220294794', 'Trimble 5700', '40406-32'),
(27, '0440100597', 'Trimble 5700', '40406-32'),
(28, '4814149941', 'Trimble 5700', '63592-00'),
(29, '4814149946', 'Trimble 5700', '63592-00'),
(30, '5035K69803', 'Trimble Net R9', '67668-10'),
(31, '5035K69860', 'Trimble Net R9', '67668-10'),
(32, '5503R50022', 'Trimble Net R9', '67668-10'),
(33, '5035K69861', 'Trimble Net R9', '67668-10'),
(34, '5049K72284', 'Trimble Net R9', '67668-10'),
(35, '5116K75192', 'Trimble Net R9', '67668-10'),
(36, '4450241606', 'Trimble Net RS', ''),
(37, '4409232263', 'Trimble Net RS', '45905-00'),
(38, '4409232247', 'Trimble Net RS', '45905-00');

-- --------------------------------------------------------

--
-- Table structure for table `scanned_logsheet`
--

CREATE TABLE `scanned_logsheet` (
  `scan_log_id` tinyint(4) NOT NULL,
  `scanned_image_path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `site_images`
--

CREATE TABLE `site_images` (
  `image_id` tinyint(4) NOT NULL,
  `image_name` varchar(10) NOT NULL,
  `image_path` varchar(100) NOT NULL,
  `image_clas_id` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_images`
--

INSERT INTO `site_images` (`image_id`, `image_name`, `image_path`, `image_clas_id`) VALUES
(1, 'MINDANAO', 'uploads\\1487052480639-mindanao_v2.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `site_information`
--

CREATE TABLE `site_information` (
  `site_info_id` tinyint(4) NOT NULL,
  `site_name` varchar(10) NOT NULL,
  `last_update` date NOT NULL,
  `latitude` double(10,5) NOT NULL,
  `longitude` double(10,5) NOT NULL,
  `receiver_sn` varchar(15) NOT NULL,
  `antenna_sn` varchar(15) NOT NULL,
  `powersource_sn` varchar(15) NOT NULL,
  `contact_id` tinyint(4) NOT NULL,
  `address_one` varchar(50) NOT NULL,
  `address_two` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL,
  `gallery_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_information`
--

INSERT INTO `site_information` (`site_info_id`, `site_name`, `last_update`, `latitude`, `longitude`, `receiver_sn`, `antenna_sn`, `powersource_sn`, `contact_id`, `address_one`, `address_two`, `city`, `province`, `gallery_name`) VALUES
(2, 'BUCA', '2017-02-02', 1.12345, 1.12345, '123456789', '123456789', '123456789', 1, 'test', 'test', 'city', 'province', 'gallery na');

-- --------------------------------------------------------

--
-- Table structure for table `site_name`
--

CREATE TABLE `site_name` (
  `site_id` int(10) NOT NULL,
  `site_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_name`
--

INSERT INTO `site_name` (`site_id`, `site_name`) VALUES
(1, 'AB14'),
(2, 'ABLA'),
(3, 'ADMI'),
(4, 'ALAB'),
(5, 'ALBU'),
(6, 'ALIC'),
(7, 'ANGT'),
(8, 'ANQ0'),
(9, 'ANTP'),
(10, 'APAR'),
(11, 'AR17'),
(12, 'AR30'),
(13, 'AROY'),
(14, 'ATIM'),
(15, 'AUR1'),
(16, 'AURA'),
(17, 'AURO'),
(18, 'BACO'),
(19, 'BAGB'),
(20, 'BAGU'),
(21, 'BAKO'),
(22, 'BALA'),
(23, 'BALU'),
(24, 'BANI'),
(25, 'BARB'),
(26, 'BASC'),
(27, 'BATC'),
(28, 'BAYB'),
(29, 'BGB1'),
(30, 'BICA'),
(31, 'BLNA'),
(32, 'BNBA'),
(33, 'BNOR'),
(34, 'BOLI'),
(35, 'BONG'),
(36, 'BONT'),
(37, 'BRG1'),
(38, 'BRGC'),
(39, 'BSCS'),
(40, 'BTS3'),
(41, 'BTUN'),
(42, 'BUCA'),
(43, 'BUGS'),
(44, 'BULA'),
(45, 'BURG'),
(46, 'BURN'),
(47, 'CABN'),
(48, 'CACA'),
(49, 'CALA'),
(50, 'CALB'),
(51, 'CALC'),
(52, 'CALI'),
(53, 'CARI'),
(54, 'CATA'),
(55, 'CATM'),
(56, 'CEA1'),
(57, 'CEB1'),
(58, 'CEBA'),
(59, 'CEBB'),
(60, 'CEBC'),
(61, 'CEBD'),
(62, 'CEBU'),
(63, 'CG95'),
(64, 'CLAV'),
(65, 'CLYN'),
(66, 'CMGN'),
(67, 'CMN2'),
(68, 'CMS2'),
(69, 'CNTA'),
(70, 'COTA'),
(71, 'COTB'),
(72, 'COTC'),
(73, 'COTD'),
(74, 'COTE'),
(75, 'COTF'),
(76, 'COTG'),
(77, 'COTH'),
(78, 'CRIS'),
(79, 'CRLN'),
(80, 'CTE1'),
(81, 'CUSV'),
(82, 'CUYP'),
(83, 'DAEJ'),
(84, 'DARW'),
(85, 'DIMA'),
(86, 'DINA'),
(87, 'DIPA'),
(88, 'DULA'),
(89, 'ELNA'),
(90, 'GABU'),
(91, 'GONZ'),
(92, 'GUAM'),
(93, 'GUIN'),
(94, 'GUMA'),
(95, 'GUNG'),
(96, 'GUNY'),
(97, 'HINA'),
(98, 'IBAZ'),
(99, 'IFG1'),
(100, 'IFR3'),
(101, 'ILN3'),
(102, 'ILO1'),
(103, 'ILO2'),
(104, 'INFA'),
(105, 'IS26'),
(106, 'IS31'),
(107, 'ISAB'),
(108, 'ISB4'),
(109, 'ITBA'),
(110, 'ITGN'),
(111, 'JOSE'),
(112, 'KA08'),
(113, 'KAYT'),
(114, 'KIBU'),
(115, 'KUNM'),
(116, 'KVMN'),
(117, 'LABO'),
(118, 'LAGW'),
(119, 'LAPS'),
(120, 'LAPU'),
(121, 'LBAN'),
(122, 'LEA1'),
(123, 'LEB1'),
(124, 'LEB2'),
(125, 'LEC1'),
(126, 'LEC2'),
(127, 'LED1'),
(128, 'LEF1'),
(129, 'LEH1'),
(130, 'LEYA'),
(131, 'LEYB'),
(132, 'LEYC'),
(133, 'LEYD'),
(134, 'LEYE'),
(135, 'LEYF'),
(136, 'LEYG'),
(137, 'LEYH'),
(138, 'LEYJ'),
(139, 'LEYM'),
(140, 'LEYO'),
(141, 'LGYE'),
(142, 'LGYN'),
(143, 'LHOV'),
(144, 'LIBA'),
(145, 'LIDO'),
(146, 'LOPE'),
(147, 'LUBU'),
(148, 'LUCB'),
(149, 'LUN1'),
(150, 'LUN2'),
(151, 'LUZA'),
(152, 'LUZB'),
(153, 'LUZC'),
(154, 'LUZD'),
(155, 'LUZE'),
(156, 'LUZF'),
(157, 'LUZG'),
(158, 'LUZH'),
(159, 'LUZI'),
(160, 'LUZL'),
(161, 'LUZN'),
(162, 'LUZP'),
(163, 'LUZR'),
(164, 'LZA1'),
(165, 'LZC1'),
(166, 'MAA1'),
(167, 'MAB1'),
(168, 'MAB2'),
(169, 'MABN'),
(170, 'MAC2'),
(171, 'MACR'),
(172, 'MAD1'),
(173, 'MAD2'),
(174, 'MAE1'),
(175, 'MAF1'),
(176, 'MAGA'),
(177, 'MAL1'),
(178, 'MALA'),
(179, 'MALG'),
(180, 'MALS'),
(181, 'MALY'),
(182, 'MAMB'),
(183, 'MAR2'),
(184, 'MARI'),
(185, 'MARK'),
(186, 'MARL'),
(187, 'MASA'),
(188, 'MASB'),
(189, 'MASC'),
(190, 'MASD'),
(191, 'MASE'),
(192, 'MASF'),
(193, 'MASG'),
(194, 'MASH'),
(195, 'MASI'),
(196, 'MASJ'),
(197, 'MASK'),
(198, 'MASL'),
(199, 'MATA'),
(200, 'MAUB'),
(201, 'MAYA'),
(202, 'MDQT'),
(203, 'MDVS'),
(204, 'MNAY'),
(205, 'MPCK'),
(206, 'MPV1'),
(207, 'MRHO'),
(208, 'MRIK'),
(209, 'MRK1'),
(210, 'MRK5'),
(211, 'MSW3'),
(212, 'MUNT'),
(213, 'MUNZ'),
(214, 'MVBM'),
(215, 'MVCH'),
(216, 'MVIC'),
(217, 'MVLC'),
(218, 'MVMH'),
(219, 'MVML'),
(220, 'MVMN'),
(221, 'MVMP'),
(222, 'MVMR'),
(223, 'MVMY'),
(224, 'MVSB'),
(225, 'MVSC'),
(226, 'MVSM'),
(227, 'MVUP'),
(228, 'N132'),
(229, 'N47A'),
(230, 'N688'),
(231, 'NAMR'),
(232, 'NAUJ'),
(233, 'NAV1'),
(234, 'NAVA'),
(235, 'NE21'),
(236, 'NLCE'),
(237, 'NLCR'),
(238, 'NLL1'),
(239, 'NLL2'),
(240, 'NLSB'),
(241, 'NLSI'),
(242, 'NLSN'),
(243, 'NMAB'),
(244, 'NMCO'),
(245, 'NMLM'),
(246, 'NMMA'),
(247, 'NMMB'),
(248, 'NMSF'),
(249, 'NMSM'),
(250, 'NOMA'),
(251, 'NOMB'),
(252, 'NOMC'),
(253, 'NOMD'),
(254, 'NOME'),
(255, 'NOMF'),
(256, 'NOMG'),
(257, 'NOMH'),
(258, 'NOMI'),
(259, 'NOMK'),
(260, 'NOML'),
(261, 'NOMZ'),
(262, 'NPAK'),
(263, 'NPAL'),
(264, 'NPIE'),
(265, 'NTUS'),
(266, 'NV47'),
(267, 'NVSM'),
(268, 'NVY2'),
(269, 'NVY3'),
(270, 'NVY9'),
(271, 'ODON'),
(272, 'PABL'),
(273, 'PAGP'),
(274, 'PAGU'),
(275, 'PALA'),
(276, 'PALM'),
(277, 'PANC'),
(278, 'PBAY'),
(279, 'PCAB'),
(280, 'PCAN'),
(281, 'PCB2'),
(282, 'PDAV'),
(283, 'PERT'),
(284, 'PFLO'),
(285, 'PGEN'),
(286, 'PHIC'),
(287, 'PHIV'),
(288, 'PIBU'),
(289, 'PILC'),
(290, 'PIMO'),
(291, 'PIVS'),
(292, 'PLEG'),
(293, 'PLWN'),
(294, 'PLYN'),
(295, 'PNBO'),
(296, 'PNG3'),
(297, 'PNG5'),
(298, 'POLI'),
(299, 'POTR'),
(300, 'PPPC'),
(301, 'PSTC'),
(302, 'PSUR'),
(303, 'PTAC'),
(304, 'PTAG'),
(305, 'PTBN'),
(306, 'PTGY'),
(307, 'PUER'),
(308, 'PUGA'),
(309, 'PURD'),
(310, 'QN42'),
(311, 'QZN2'),
(312, 'QZN3'),
(313, 'QZN6'),
(314, 'RCPS'),
(315, 'ROXA'),
(316, 'S289'),
(317, 'SABL'),
(318, 'SANA'),
(319, 'SHAO'),
(320, 'SIBA'),
(321, 'SIBB'),
(322, 'SIBC'),
(323, 'SIBD'),
(324, 'SIBE'),
(325, 'SIBF'),
(326, 'SIBH'),
(327, 'SIBI'),
(328, 'SIBJ'),
(329, 'SIBK'),
(330, 'SIBL'),
(331, 'SINA'),
(332, 'SINB'),
(333, 'SINC'),
(334, 'SIND'),
(335, 'SINE'),
(336, 'SINF'),
(337, 'SING'),
(338, 'SINH'),
(339, 'SINI'),
(340, 'SISN'),
(341, 'SJAQ'),
(342, 'SLSB'),
(343, 'SMAT'),
(344, 'SMCL'),
(345, 'SMCP'),
(346, 'SMD1'),
(347, 'SMDB'),
(348, 'SMDM'),
(349, 'SMDS'),
(350, 'SMDT'),
(351, 'SMMM'),
(352, 'SMSK'),
(353, 'SNNI'),
(354, 'SOLA'),
(355, 'SOLB'),
(356, 'SOLC'),
(357, 'SOLD'),
(358, 'SOLE'),
(359, 'SOLF'),
(360, 'SOLG'),
(361, 'SOLH'),
(362, 'SOLI'),
(363, 'SOLJ'),
(364, 'SOLK'),
(365, 'SOLL'),
(366, 'SOMA'),
(367, 'SOMB'),
(368, 'SOMC'),
(369, 'SOMD'),
(370, 'SOME'),
(371, 'SOMF'),
(372, 'SOMG'),
(373, 'SOMH'),
(374, 'SOMI'),
(375, 'SOMJ'),
(376, 'SOMK'),
(377, 'SOML'),
(378, 'SOMM'),
(379, 'SONO'),
(380, 'SPAB'),
(381, 'SRQE'),
(382, 'STNA'),
(383, 'SUAL'),
(384, 'TABA'),
(385, 'TACB'),
(386, 'TACL'),
(387, 'TAFT'),
(388, 'TAGA'),
(389, 'TAGB'),
(390, 'TAIW'),
(391, 'TANY'),
(392, 'TARL'),
(393, 'TAWI'),
(394, 'TCGN'),
(395, 'TGDN'),
(396, 'TNDG'),
(397, 'TNML'),
(398, 'TOF1'),
(399, 'TONA'),
(400, 'TONF'),
(401, 'TONU'),
(402, 'TONW'),
(403, 'TRC3'),
(404, 'TRL1'),
(405, 'TRLC'),
(406, 'TSKB'),
(407, 'TUAO'),
(408, 'TUKU'),
(409, 'TWTF'),
(410, 'UP02'),
(411, 'URDT'),
(412, 'USUD'),
(413, 'VIGN'),
(414, 'VMAN'),
(415, 'VMRH'),
(416, 'VMSM'),
(417, 'VRAC'),
(418, 'VRC1'),
(419, 'VRC2'),
(420, 'VRC3'),
(421, 'VRC4'),
(422, 'VTBM'),
(423, 'VTCT'),
(424, 'VTDK'),
(425, 'WUHA'),
(426, 'WUHN'),
(427, 'ZBS1'),
(428, 'ZBS3'),
(429, 'ZMPS');

-- --------------------------------------------------------

--
-- Table structure for table `site_sketch`
--

CREATE TABLE `site_sketch` (
  `sketch_id` tinyint(4) NOT NULL,
  `sketch_name` varchar(10) NOT NULL,
  `sketch_path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `survey_type`
--

CREATE TABLE `survey_type` (
  `survey_id` tinyint(4) NOT NULL,
  `survey_type_info` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey_type`
--

INSERT INTO `survey_type` (`survey_id`, `survey_type_info`) VALUES
(1, 'campaign'),
(2, 'contineous');

-- --------------------------------------------------------

--
-- Table structure for table `test_table`
--

CREATE TABLE `test_table` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(45) NOT NULL,
  `employee_contact` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_table`
--

INSERT INTO `test_table` (`employee_id`, `employee_name`, `employee_contact`) VALUES
(1, '', ''),
(2, '', ''),
(3, 'yes1', 'test2'),
(4, ' + name + ', ' + contact + '),
(5, '+reqObj.employee_name+', '+reqObj.employee_contact+'),
(6, 'employee_name', 'employee_contact'),
(7, 'employee_name', 'employee_contact'),
(8, 'test1', 'test2'),
(9, 'test1', 'test2'),
(10, 'test1', 'test2'),
(11, 'employee_name', 'employee_contact'),
(12, 'employee_name', 'employee_contact'),
(13, 'undefined', 'undefined'),
(14, 'test1', 'test2'),
(15, 'test1', 'test2'),
(16, 'test1', 'test2'),
(17, 'test1', 'test2'),
(18, 'test1', 'test2'),
(19, 'test', 'test'),
(20, 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `test_table2`
--

CREATE TABLE `test_table2` (
  `employee_id` int(11) NOT NULL,
  `employee_position` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_table2`
--

INSERT INTO `test_table2` (`employee_id`, `employee_position`) VALUES
(1, 'employee_position'),
(2, 'employee_position'),
(3, 'undefined'),
(4, 'test3'),
(5, 'test3'),
(6, 'test3'),
(7, 'test3'),
(8, 'test3'),
(9, 'test'),
(10, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `velocity`
--

CREATE TABLE `velocity` (
  `site_id` tinyint(4) NOT NULL,
  `date` date NOT NULL,
  `receiver_serial_number` varchar(45) NOT NULL,
  `velocity_north` float(7,5) NOT NULL,
  `velocity_east` float(7,5) NOT NULL,
  `velocity_up` float(7,5) NOT NULL,
  `velocitynorthrange` varchar(45) NOT NULL,
  `velocityeastrange` varchar(45) NOT NULL,
  `velocityuprange` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `antenna_information`
--
ALTER TABLE `antenna_information`
  ADD PRIMARY KEY (`antenna_id`),
  ADD UNIQUE KEY `antenna_serialnumber` (`antenna_serialnumber`);

--
-- Indexes for table `associated_agency`
--
ALTER TABLE `associated_agency`
  ADD PRIMARY KEY (`agency_id`);

--
-- Indexes for table `contact_person`
--
ALTER TABLE `contact_person`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `data_table`
--
ALTER TABLE `data_table`
  ADD PRIMARY KEY (`site_id`);

--
-- Indexes for table `fieldwork_table`
--
ALTER TABLE `fieldwork_table`
  ADD PRIMARY KEY (`fieldwork_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`gallery_id`),
  ADD KEY `gallery_name` (`gallery_name`);

--
-- Indexes for table `gps_staff_info`
--
ALTER TABLE `gps_staff_info`
  ADD PRIMARY KEY (`staf_id`);

--
-- Indexes for table `image_class`
--
ALTER TABLE `image_class`
  ADD PRIMARY KEY (`image_clas_id`);

--
-- Indexes for table `logistical_notes`
--
ALTER TABLE `logistical_notes`
  ADD PRIMARY KEY (`logistical_note_id`);

--
-- Indexes for table `logsheet`
--
ALTER TABLE `logsheet`
  ADD PRIMARY KEY (`logsheet_id`);

--
-- Indexes for table `observer`
--
ALTER TABLE `observer`
  ADD PRIMARY KEY (`observer_id`);

--
-- Indexes for table `office_division`
--
ALTER TABLE `office_division`
  ADD PRIMARY KEY (`division_id`),
  ADD UNIQUE KEY `division` (`division`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`position_id`),
  ADD UNIQUE KEY `position_name` (`position_name`);

--
-- Indexes for table `power_source`
--
ALTER TABLE `power_source`
  ADD PRIMARY KEY (`ps_id`),
  ADD UNIQUE KEY `ps_serial_number` (`ps_serial_number`);

--
-- Indexes for table `receiver_information`
--
ALTER TABLE `receiver_information`
  ADD PRIMARY KEY (`receiver_id`),
  ADD UNIQUE KEY `serial_number` (`serial_number`);

--
-- Indexes for table `scanned_logsheet`
--
ALTER TABLE `scanned_logsheet`
  ADD PRIMARY KEY (`scan_log_id`),
  ADD UNIQUE KEY `scanned_image_path` (`scanned_image_path`);

--
-- Indexes for table `site_images`
--
ALTER TABLE `site_images`
  ADD PRIMARY KEY (`image_id`),
  ADD UNIQUE KEY `image_name` (`image_name`);

--
-- Indexes for table `site_information`
--
ALTER TABLE `site_information`
  ADD PRIMARY KEY (`site_info_id`);

--
-- Indexes for table `site_name`
--
ALTER TABLE `site_name`
  ADD PRIMARY KEY (`site_id`),
  ADD UNIQUE KEY `site_name` (`site_name`);

--
-- Indexes for table `site_sketch`
--
ALTER TABLE `site_sketch`
  ADD PRIMARY KEY (`sketch_id`);

--
-- Indexes for table `survey_type`
--
ALTER TABLE `survey_type`
  ADD PRIMARY KEY (`survey_id`),
  ADD UNIQUE KEY `survey_type_info` (`survey_type_info`);

--
-- Indexes for table `test_table`
--
ALTER TABLE `test_table`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `test_table2`
--
ALTER TABLE `test_table2`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `velocity`
--
ALTER TABLE `velocity`
  ADD PRIMARY KEY (`site_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `antenna_information`
--
ALTER TABLE `antenna_information`
  MODIFY `antenna_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `associated_agency`
--
ALTER TABLE `associated_agency`
  MODIFY `agency_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `contact_person`
--
ALTER TABLE `contact_person`
  MODIFY `contact_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `fieldwork_table`
--
ALTER TABLE `fieldwork_table`
  MODIFY `fieldwork_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gps_staff_info`
--
ALTER TABLE `gps_staff_info`
  MODIFY `staf_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `image_class`
--
ALTER TABLE `image_class`
  MODIFY `image_clas_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `logistical_notes`
--
ALTER TABLE `logistical_notes`
  MODIFY `logistical_note_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `logsheet`
--
ALTER TABLE `logsheet`
  MODIFY `logsheet_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `observer`
--
ALTER TABLE `observer`
  MODIFY `observer_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `office_division`
--
ALTER TABLE `office_division`
  MODIFY `division_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `position_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `power_source`
--
ALTER TABLE `power_source`
  MODIFY `ps_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `receiver_information`
--
ALTER TABLE `receiver_information`
  MODIFY `receiver_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `scanned_logsheet`
--
ALTER TABLE `scanned_logsheet`
  MODIFY `scan_log_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `site_images`
--
ALTER TABLE `site_images`
  MODIFY `image_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `site_information`
--
ALTER TABLE `site_information`
  MODIFY `site_info_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `site_name`
--
ALTER TABLE `site_name`
  MODIFY `site_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=430;
--
-- AUTO_INCREMENT for table `site_sketch`
--
ALTER TABLE `site_sketch`
  MODIFY `sketch_id` tinyint(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `survey_type`
--
ALTER TABLE `survey_type`
  MODIFY `survey_id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `test_table`
--
ALTER TABLE `test_table`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `test_table2`
--
ALTER TABLE `test_table2`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `velocity`
--
ALTER TABLE `velocity`
  MODIFY `site_id` tinyint(4) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
